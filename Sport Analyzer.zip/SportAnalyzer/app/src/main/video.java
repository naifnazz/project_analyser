public class video {
    string path;
    string titile;

    public string getPath() {
        return path;
    }

    public void setPath(string path) {
        this.path = path;
    }

    public string getTitile() {
        return titile;
    }

    public void setTitile(string titile) {
        this.titile = titile;
    }

    public string getVideouri() {
        return videouri;
    }

    public void setVideouri(string videouri) {
        this.videouri = videouri;
    }

    string videouri;

}
